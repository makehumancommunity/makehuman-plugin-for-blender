# MH Community 

This is a blender plugin which brings features related to MakeHuman

## Sync mesh

## Sync pose

## IK

## (etc...)
